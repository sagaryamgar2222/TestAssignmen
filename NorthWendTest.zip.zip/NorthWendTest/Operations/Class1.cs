﻿namespace Operations
{
    public class Class1
    {

    }
}