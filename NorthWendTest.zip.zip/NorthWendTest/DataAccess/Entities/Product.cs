﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAccess.Entities
{
    public class Product
    {
      
          public  string ProductName { get; set; }

        public string MonthName { get; set; }

        public decimal TotalPrice { get; set; }
        
    }
}
