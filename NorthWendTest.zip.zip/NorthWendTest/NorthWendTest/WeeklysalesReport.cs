﻿using System;

namespace NorthWendTest
{
    internal class WeeklysalesReport
    {
        internal static void Execute()
        {
            Console.WriteLine("=======================");

            Console.WriteLine("Workin on this Page");

            Console.WriteLine("=====================");
        }
    }
}