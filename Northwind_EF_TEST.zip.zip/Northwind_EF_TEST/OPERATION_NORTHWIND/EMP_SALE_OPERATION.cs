﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OPERATION_NORTHWIND
{
    public class EMP_SALE_OPERATION
    {
      

    }
}
