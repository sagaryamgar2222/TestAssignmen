﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Northwind_EF_TEST.OPERATIONS
{
    public class PRO_WR_OPERATION
    {
        public static void PWR_Execute()
        {
            using (var db = new NorthwindEntities1())
            {
                Console.WriteLine("Enter product name");
                string Productname = Console.ReadLine();
                Console.WriteLine("Enter month");


                string month = Console.ReadLine();
                Console.WriteLine("Enter year");

                string Year = Console.ReadLine();

                Console.Clear();
                var PWR = db.Q3_ProductWiseMonthlyReport(Productname, month, Year).ToList();
                // int cnt = 0;

                foreach (var pwr in PWR)
                {
                     Console.WriteLine($" ProductName \t\t:{pwr.ProductName} \n Month \t\t\t:{pwr.month} \n TotalCost \t\t:{pwr.TatalCost}  \n ----------------------------------");
                   // cnt++;
                }


                Console.ReadLine();
            }

        }

    }
}
