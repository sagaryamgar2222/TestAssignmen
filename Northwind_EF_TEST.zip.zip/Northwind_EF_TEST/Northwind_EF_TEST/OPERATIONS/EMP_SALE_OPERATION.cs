﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Northwind_EF_TEST.OPERATIONS
{
    public class EMP_SALE_OPERATION
    {

        public static void empExecute()
        {
            using (var db = new NorthwindEntities1())
            {
                Console.WriteLine("Enter employee id");
                int @EMP_ID = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter from date");

                string @FROM_DATE = Console.ReadLine();// "1996-07-04";
                Console.WriteLine("Enter to date");


                string @TO_DATE = Console.ReadLine();// "1997-07-04";
                Console.Clear();
                var emplo = db.Q1EmployeeSalesReport(@EMP_ID, @FROM_DATE, @TO_DATE).ToList();
                int cnt = 0;
                foreach (var emp in emplo)
                {
                    Console.WriteLine($" EmployeeID  \t\t:{emp.EmployeeID} \n FIRSTNAME \t\t:{emp.FirstName} \n LASTNAME \t\t:{emp.LastName} \n ORDERID \t\t:{emp.OrderId} \n ----------------------------------");

                    cnt++;
                }
                if(cnt==0)

                Console.ReadLine();
            }

        }
    }
}
